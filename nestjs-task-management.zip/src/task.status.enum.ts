export enum Taskstatus
{
    OPEN= "open",
    DONE= "done",
    IN_PROGRESS="in_progress",


}
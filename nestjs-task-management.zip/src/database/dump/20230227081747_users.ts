import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {
    return knex.schema
    .createTable('user_table', table => {
      table.increments('id').primary();
      table.string('username').notNullable().unique();
      table.string('password').notNullable();
      table.string('user_salt');
    
    })
      

}


export async function down(knex: Knex): Promise<void> {
    return knex.schema
    .dropTableIfExists('user_table')
}

